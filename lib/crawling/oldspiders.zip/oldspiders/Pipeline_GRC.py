"""
Copyright (c) 2013 Tommy Carpenter

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/topics/item-pipeline.html
from unidecode import unidecode #used to convert strange unicode into ascii
from generalFuncs import ContractionsTagsWhitey, executeInsert

import re


#cleans the GRC items before being entered into the database. 
class GCRClean(object):
   def process_item(self, item, spider):
      if 'GCRClean' not in getattr(spider, 'pipelines'):
         return item
      
      #FIx the title if it contains contractions
      item['title'] = ContractionsTagsWhitey(item['title']) 
   
      #fix many things wrong with the body
      text = ""
      for b in range(1,len(item['body'])): #theres one <p> on the begining of every page that is not part of body, so start at 1
         s = unidecode(item['body'][b]).replace("<p>","").replace("</p>","").replace("<span>","").replace("</span>","")
         s = s.replace("Follow GreenCarReports on Facebook and Twitter.","").replace("+++++++++++","") #this follows the end of every article
         s = ContractionsTagsWhitey(s)
         text += s
      item['body'] = text
        
      #fix number of comments
      if(len(item['numcomments']) == 0):
         item['numcomments'] = int(0) 
      else:
         item['numcomments'] = int(unidecode(item['numcomments'][0]).split("(")[1].split(")")[0])
      
      #FOR SOME REAson only every other one is valid
      newcommentdates = []
      for x in range(0,len(item['commentdates'])):
          nd = unidecode(item['commentdates'][x].strip())
          if (nd != ""):
              newcommentdates.append(nd)

       #make the comments into pairs {date, comment}
      comments = ""
      for c in range(0,len(item['comments'])):
         thec = "{"
         thec += newcommentdates[c].split(" ")[1]
         thec += ","
         thec += unidecode(item['comments'][c])
         thec = ContractionsTagsWhitey(thec).replace("                            ","")
         thec+="}\n"
         comments += thec
      item['newCommentFormat'] = comments
      return item
 


#put the items in de db      
class GCRDB(object):    
   def process_item(self, item, spider): 
      if 'GCRDB' not in getattr(spider, 'pipelines'):
         return item

      Query = 'insert into GreenCarReports (BaseSite,Content,Title,Author,PostDate,Views,Url,Body,NumComments,Comments) values (\'{0}\', \'{1}\', \'{2}\', \'{3}\',\'{4}\', \'{5}\',\'{6}\', \'{7}\', \'{8}\',\'{9}\')'.format(item['site'],item['contenttype'],item['title'],item['author'],item['postDate'],item['views'],item['url'],item['body'],item['numcomments'],item['newCommentFormat'])
      executeInsert(Query,item['url'])
      return item
