"""
Copyright (c) 2013 Tommy Carpenter

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""

from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.selector import HtmlXPathSelector
from GreenCarScraper.items import pluginCarsItem
from unidecode import unidecode #used to convert strange unicode into ascii

#crawLs 'http://www.plugincars.com/discussions' which contains both articles and discussions
class pluginCarsSpider(CrawlSpider):
   name = 'pluginCarsSpider'
   allowed_domains = ['www.plugincars.com']
   start_urls=['http://www.plugincars.com/discussions']
   pipelines = ['pluginCarsClean','pluginCarsDB']

   rules = ( 
   #follow links to car specific news pages: 'http://www.plugincars.com/CAR-X/discussions'....
   Rule(SgmlLinkExtractor(allow=('/[^/]+/discussions')), follow=True),
   
   #follow links to the next news pages: 'http://www.plugincars.com/discussions?page=X'....
   Rule(SgmlLinkExtractor(allow=('/discussions\?page=[0-9]+[.]*')), follow=True),
   
   #parse the news articles of the form http://www.plugincars.com/blah-blah-blah.html
   #do not allow http://www.plugincars.com/user/blah.html
   Rule(SgmlLinkExtractor(allow=('/[^\.]+\.html'), deny = ('/user[/][.]*',
                                                     '/users[/][.]*',
                                                     '/guides\.html',
                                                     '/privacy-policy\.html',
                                                     '/newsletter\.html')), callback='parse_item',follow=False),
   
   )

   #parsing function 
   def parse_item(self, response):
      hxs = HtmlXPathSelector(response)
      item = pluginCarsItem()
     
      item['site'] = "http://www.plugincars.com/discussions"
      
      #content type must be parsed
      #<p class="more"><a href="/discussions">
      l = hxs.select('//p[@class="more"]//a[@href="/discussions"]').extract()
      item['contenttype'] = ("Article" if len(l) == 0 else "Discussion")

      #  <title>What is the latest news about the Aptera? | PluginCars.com</title>
      item['title'] = unidecode(hxs.select('//title/text()').extract()[0])
      
      item['url'] = unidecode(response.url) 
      
      
      #two different article types
      type = hxs.select('//p[@class="author"]/text()').extract()
      type = ( 1  if len(type) > 0 else 2)
      #no author if discusssion
      # authors come in two formats (looks like format was changed over time)
      #type1: <p class="author">By <a href="/user/zach-mcdonald" title="View user profile.">Zach McDonald</a>
      #type2: <a href="/user/michael-coates" title="View user profile.">Michael Coates</a>  <span class="dot-a">
      if item['contenttype'] == "Discussion":
          item['author'] = "N/A" 
      else: 
          item['author'] = unidecode((hxs.select('//p[@class="author"]//a/text()').extract()[0]) if type==1 else 
                            unidecode(hxs.select('(//a[@title="View user profile."])/text()').extract()[0]))
      #date come in two formats (looks like format was changed over time)
      #discussion date and type 2 author date are the same
      #date: first: <p class="author">By<span class="dot-a">&middot;</span> October 15, 2012</p>
      #date: second: <p class="person"><span class="time">DATEHERE</span>
      item['postDate'] = (unidecode(hxs.select('//p[@class="author"]/text()').extract()[2]) if type==1 
                          else unidecode(hxs.select('//p[@class="person"]//span[@class="time"]/text()').extract()[0]))
                           
      #no body if disscussion: all content follows comments
      if item['contenttype'] == "Discussion":
           item['body'] = ""
      else:
           #type1: <div class="article-a"><p....>
           #type2: #<div class="post"> <-- first one of these <p...>
            b = ( hxs.select('//div[@class="article-a"]//p/text()').extract()  if type==1 else
                            hxs.select('(//div[@class="post"])[1]//p/text()').extract())                    
            if type==1:
               b.pop(0)
               b.pop(0)
               b.pop(0)
            item['body'] = b
            
      #this page does not explicity state the number of comments
      #dealt with in pipeline file
      item['numcomments'] = -1

      #get the post date of all comments. will merge these later with comments
      #date:<p class="person"><span class="time">DATEHERE</span>
      item['commentdates'] = hxs.select('//p[@class="person"]//span[@class="time"]/text()').extract()        
      
      #comments are easy in this one
      # <div class="content" style="min-height: 62px;"> 
      item['comments'] = hxs.select('//div[@class="post"]').extract()
      return item









