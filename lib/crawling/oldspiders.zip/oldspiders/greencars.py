"""
Copyright (c) 2013 Tommy Carpenter

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""

from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.selector import HtmlXPathSelector
from GreenCarScraper.items import GCRItem
from unidecode import unidecode #used to convert strange unicode into ascii

#crawLs 'http://www.greencarreports.com/news'
class GCRNewsSpider(CrawlSpider):
   name = 'GCRNewsSpider'
   allowed_domains = ['www.greencarreports.com']
   start_urls=['http://www.greencarreports.com/news']
   pipelines = ['GCRClean','GCRDB'] #define which pipelines will work
   
   rules = ( 
   #parse the news articles that start with a number
   Rule(SgmlLinkExtractor(allow=('/news/[0-9]+.*', )), callback='parse_item',follow=False),
   
   #follow the links to the next news pages: 'http://www.greencarreports.com/news/page-X'....
   Rule(SgmlLinkExtractor(allow=('/news/page-.*', )), follow=True),
   )
    
   def parse_item(self, response):
      hxs = HtmlXPathSelector(response)
      item = GCRItem()
     
      item['site'] = "http://www.greencarreports.com/news"
      item['contenttype'] = "Article"

      #<title>Driving An Electric Car? You'll See So Much More Stuff!</title>
      item['title'] = unidecode(hxs.select('//title/text()').extract()[0])
      
      #<div itemprop="author" itemscope itemtype="http://schema.org/Person" class="reviewer">
      #  By <a href="http://www.highgearmedia.com/user/10009362_antony-ingram">
      #      <img class="" src="http://images.thecarconnection.com/sml/avatar-image-for-aingram-ace_100327516_s.jpg" alt="Antony Ingram" />
      #</a> 
      item['author'] = unidecode(hxs.select('(//div[@itemprop="author"]//img)[1]/@alt').extract()[0])
      
      #the last one of these: <span class="date">Aug 24, 2012</span>
      # theres a bunch at the top of page refering to other articles
      item['postDate'] = unidecode(hxs.select('(//span[@class="date"])[last()]/text()').extract()[0])
      
      #    <ul class="story-stats">
      #        <li class="page-views">2,076 Views</li>
      #        stuff at the end just converts u'y,yyy' to int(yyyy)
      item['views'] = int(hxs.select('//ul[@class="story-stats"]//li[@class="page-views"]/text()').extract()[0].encode().split(" ")[0].replace(',',''))

      #easy
      item['url'] = unidecode(response.url) 
      
      #get all <p> blocks that do not have attributes. 
      item['body'] = hxs.select('//p[not(@*)]').extract()
      #printItems(item)

      #<span class="commentCount">Comments (2)</span>
      item['numcomments'] = hxs.select('//span[@class="commentCount"]/text()').extract()
      
      # <li id="comment-1000143225" ...><p class='byline'>
      item['commentdates'] = hxs.select('//li[starts-with(@id,"comment-")]//p[@class=\'byline\']/text()').extract()

      #<div class="comment-content">commentinHEA</div>                                   
      item['comments'] = hxs.select('//div[@class="comment-content"]').extract()
      return item




#crawLs 'http://www.greencarreports.com/news'
class GCRReviewsSpider(CrawlSpider):
   name = 'GCRReviewsSpider'
   allowed_domains = ['www.greencarreports.com']
   start_urls=['http://www.greencarreports.com/reviews']
   pipelines = ['GCRClean','GCRDB'] #define which pipelines will work

   rules = ( 
   #parse the review articles that start with a number
   Rule(SgmlLinkExtractor(allow=('/overview/[a-zA-Z]+.*', )), callback='parse_item',follow=False),
   
   Rule(SgmlLinkExtractor(allow=('/review/[0-9]+.*', )), callback='parse_item',follow=False),

   #follow the links to the next news pages: 'http://www.greencarreports.com/news/page-X'....
   Rule(SgmlLinkExtractor(allow=('/reviews/[0-9]+', )), follow=True),
   )
    
   def parse_item(self, response):
      #print('Hi, this is an item page! %s' % )
      #print("\n")
      hxs = HtmlXPathSelector(response)
      item = GCRItem()
     
      item['site'] = "http://www.greencarreports.com/reviews"
      item['contenttype'] = "Car Review"

      #<title>Driving An Electric Car? You'll See So Much More Stuff!</title>
      item['title'] = unidecode(hxs.select('//title/text()').extract()[0])
      
      #<div itemprop="author" itemscope itemtype="http://schema.org/Person" class="reviewer">
      #  By <a href="http://www.highgearmedia.com/user/10009362_antony-ingram">
      #      <img class="" src="http://images.thecarconnection.com/sml/avatar-image-for-aingram-ace_100327516_s.jpg" alt="Antony Ingram" />
      #</a> 
      item['author'] = unidecode(hxs.select('(//div[@itemprop="author"]//img)[1]/@alt').extract()[0])
      
      #the last one of these: <span class="date">Aug 24, 2012</span>
      # theres a bunch at the top of page refering to other articles
      item['postDate'] = unidecode(hxs.select('(//span[@class="date"])[last()]/text()').extract()[0])
      
      #THE OVERVIEW PAGES HAVE
		#  <span class="page-view">1,429 views</span>
      #THE REVIEWS PAGES HAS 
      #<ul class="story-stats">
      #    <li class="page-views">5,887 Views</li>
      #        all the crap at the end just converts u'y,yyy' to int(yyyy)
      v = hxs.select('//ul[@class="story-stats"]//li[@class="page-views"]/text()').extract()
      if len(v) == 0:
         v = hxs.select('//span[@class="page-view"]/text()').extract()#[0].encode().split(" ")[0].replace(',',''))
      v=v[0].encode().split(" ")[0].replace(',','')
      item['views'] = v
      
      #easy
      item['url'] = unidecode(response.url) 
      
      #get all <p> blocks that do not have attributes. 
      item['body'] = hxs.select('//p[not(@*)]').extract()
      #printItems(item)

      #<span class="commentCount">Comments (2)</span>
      item['numcomments'] = hxs.select('//span[@class="commentCount"]/text()').extract()

      # <li id="comment-1000143225" ...><p class='byline'>
      item['commentdates'] = hxs.select('//li[starts-with(@id,"comment-")]//p[@class=\'byline\']/text()').extract()
      
      #<div class="comment-content">commentinHEA</div>                                   
      item['comments'] = hxs.select('//div[@class="comment-content"]').extract()
      return item
