"""
Copyright (c) 2013 Tommy Carpenter

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""

# Define your item pipelines here
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/topics/item-pipeline.html
from unidecode import unidecode #used to convert strange unicode into ascii
from generalFuncs import ContractionsTagsWhitey, executeInsert

import re

#cleans the GRC items before being entered into the database. 
class hybridCarsClean(object):
   def process_item(self, item, spider):
       if 'hybridCarsClean' not in getattr(spider, 'pipelines'):
          return item
       
       #fix the title and replace contractions with ''
       item['title'] = item['title'].split("- Review")[0]
       item['title'] = ContractionsTagsWhitey(item['title']) 

       #fix many things wrong with the body
       text = ""
       for b in range(0,len(item['body'])): 
          s = unidecode(item['body'][b])
          s = ContractionsTagsWhitey(s)
          text += s
       item['body'] = text
  
       #this page does not explicity state the number of comments
       #dealt with in pipeline file
       item['numcomments'] = int(len(item['comments']))
       
       #make the comments into one || seperated string
       comments = ""
       for c in range(0,len(item['comments'])):
          thec = "{"
          thec += unidecode(item['commentdates'][c])
          thec += ","
          thec += unidecode(item['comments'][c])
          thec = re.sub('<a href[^>]*>Report this page</a>','',thec) #get of ``Report this page'' in the html link 
          thec = re.sub('<span[^>]*>flagged</span>','',thec) #kill flagged in <span....flagged>
          thec = re.sub('<a href[^>]*>reply</a>','',thec) #get of the word reply in the html link
          thec = ContractionsTagsWhitey(thec)
          thec += "}\n"
          comments += thec
       item['newCommentFormat'] = comments
       return item
 


#put the items in de db      
class hybridCarsDB(object):    
   def process_item(self, item, spider):
       if 'hybridCarsDB' not in getattr(spider, 'pipelines'):
          return item

       Query = 'insert into HybridCars (BaseSite,Content,Title,Url,Body,NumComments,Comments) values (\'{0}\', \'{1}\', \'{2}\', \'{3}\',\'{4}\', \'{5}\',\'{6}\')'.format(item['site'],item['contenttype'],item['title'],item['url'],item['body'],item['numcomments'],item['newCommentFormat'])
       executeInsert(Query,item['url'])
       return item

