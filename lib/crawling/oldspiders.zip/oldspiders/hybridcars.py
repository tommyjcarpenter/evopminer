"""
Copyright (c) 2013 Tommy Carpenter

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
"""

from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.contrib.linkextractors.sgml import SgmlLinkExtractor
from scrapy.selector import HtmlXPathSelector
from GreenCarScraper.items import HybridCarsItem
from unidecode import unidecode #used to convert strange unicode into ascii

class hybridCarsSpider(CrawlSpider):
   name = 'hybridCarsSpider'
   allowed_domains = ['www.hybridcars.com']
   start_urls=['http://www.hybridcars.com/hybrid-cars-list']
   pipelines = ['hybridCarsClean','hybridCarsDB']

   #only one page of links, no need for a follow rule
   rules = ( 
   ##parse the news articles that start with a number
   Rule(SgmlLinkExtractor(allow=('/vehicle/[a-zA-Z]+.*', )), callback='parse_item',follow=False),
   )

   #parsing function 
   def parse_item(self, response):
      #print('Hi, this is an item page! %s' % )
      #print("\n")
      hxs = HtmlXPathSelector(response)
      item = HybridCarsItem()
     
      item['site'] = "http://www.hybridcars.com/hybrid-cars-list"
      item['contenttype'] = "Car Review"

      #<title>2012 Mitsubishi i-MiEV Review - Review | Hybrid Cars</title>
      item['title'] = unidecode(hxs.select('//title/text()').extract()[0])
      
      #easy
      item['url'] = unidecode(response.url) 
      
      ##get all <p> blocks that do not have attributes. 
      item['body'] = hxs.select('//div[@id="main-content"]//p/text()').extract()

      #this page does not explicity state the number of comments
      #dealt with in pipeline file
      item['numcomments'] = -1

      #<div class="posted"><p>2 days ago</p></div>
      item['commentdates'] = hxs.select('//div[@class="posted"]//p/text()').extract()
      
      # <div class="content" style="min-height: 62px;"> 
      item['comments'] = hxs.select('//div[@class="content" and @style="min-height: 62px;"]').extract()
      return item
